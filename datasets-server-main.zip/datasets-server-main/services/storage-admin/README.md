# Datasets server - storage admin

> A Ubuntu machine to log into and manage the storage manually
