# SPDX-License-Identifier: Apache-2.0
# Copyright 2022 The HuggingFace Authors.

from rows.app import start

if __name__ == "__main__":
    start()
