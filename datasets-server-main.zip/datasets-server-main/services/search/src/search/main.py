# SPDX-License-Identifier: Apache-2.0
# Copyright 2023 The HuggingFace Authors.

from search.app import start

if __name__ == "__main__":
    start()
