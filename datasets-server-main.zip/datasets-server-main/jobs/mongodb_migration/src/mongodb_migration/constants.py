# SPDX-License-Identifier: Apache-2.0
# Copyright 2022 The HuggingFace Authors.

DATABASE_MIGRATIONS_COLLECTION_MIGRATIONS = "databaseMigrations"
DATABASE_MIGRATIONS_MONGOENGINE_ALIAS = "maintenance"
